/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;

char *STD_STANDARD;
char *UNISIM_P_0947159679;
char *IEEE_P_2592010699;
char *IEEE_P_1242562249;
char *VL_P_2533777724;
char *IEEE_P_3620187407;
char *IEEE_P_3499444699;
char *IEEE_P_1367372525;
char *UNISIM_P_3222816464;
char *STD_TEXTIO;
char *IEEE_P_2717149903;
char *IEEE_P_0774719531;


int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    work_m_00000000001486985232_3694663422_init();
    work_m_00000000003384345003_1335981909_init();
    work_m_00000000000838786020_3685369199_init();
    work_m_00000000001935764027_4068815835_init();
    work_m_00000000000838786020_3840542970_init();
    work_m_00000000000197330456_1810897040_init();
    work_m_00000000000197330456_0613992218_init();
    work_m_00000000000197330456_3180435104_init();
    work_m_00000000002659529784_3852175186_init();
    work_m_00000000001795195107_3026462019_init();
    work_m_00000000004107729085_1999848201_init();
    work_m_00000000002783655651_3620696739_init();
    work_m_00000000001198514555_1628651944_init();
    work_m_00000000003931841455_4001570012_init();
    work_m_00000000003116838810_0617755897_init();
    work_m_00000000000838786020_1946989469_init();
    work_m_00000000002730383066_0529600850_init();
    work_m_00000000002730383066_1349553535_init();
    work_m_00000000002730383066_2643968043_init();
    work_m_00000000002703739995_1619333912_init();
    work_m_00000000000838786020_0289983693_init();
    work_m_00000000003538329480_2431519726_init();
    work_m_00000000002469713659_1042884758_init();
    work_m_00000000003837669281_2713931932_init();
    work_m_00000000003630370168_0948342941_init();
    work_m_00000000000219521380_1534820681_init();
    work_m_00000000002505093003_2550034667_init();
    work_m_00000000004021068376_2427087678_init();
    work_m_00000000000519621299_3211920256_init();
    work_m_00000000000237502764_4200472578_init();
    work_m_00000000004134447467_2073120511_init();
    ieee_p_2592010699_init();
    ieee_p_1242562249_init();
    unisim_p_0947159679_init();
    vl_p_2533777724_init();
    unisim_a_2661327437_0605893366_init();
    unisim_a_2216889161_3025253650_init();
    work_a_1199338142_3212880686_init();
    unisim_a_1801614988_1818890047_init();
    work_a_2301815060_3212880686_init();
    unisim_a_3055263662_1392679692_init();
    unisim_a_3762448000_2971575191_init();
    unisim_a_1717296735_4086321779_init();
    unisim_a_2562466605_1496654361_init();
    work_a_1733440043_3212880686_init();
    ieee_p_3499444699_init();
    ieee_p_3620187407_init();
    work_a_2985613686_2112914709_init();
    work_a_1720112180_0366893413_init();
    unisim_a_2536841925_1281047780_init();
    unisim_a_3870564484_3219970547_init();
    work_a_3410330957_3212880686_init();
    work_a_1739854188_3212880686_init();
    ieee_p_0774719531_init();
    std_textio_init();
    ieee_p_2717149903_init();
    ieee_p_1367372525_init();
    unisim_p_3222816464_init();
    unisim_a_2416516301_2147906635_init();
    work_a_0067143618_3212880686_init();
    work_a_3341417687_3212880686_init();
    unisim_a_0350208134_1521797606_init();
    work_a_3448733490_3212880686_init();
    work_a_4168484336_3212880686_init();
    work_a_3447067622_3212880686_init();


    xsi_register_tops("work_m_00000000000237502764_4200472578");
    xsi_register_tops("work_m_00000000004134447467_2073120511");

    STD_STANDARD = xsi_get_engine_memory("std_standard");
    UNISIM_P_0947159679 = xsi_get_engine_memory("unisim_p_0947159679");
    IEEE_P_2592010699 = xsi_get_engine_memory("ieee_p_2592010699");
    xsi_register_ieee_std_logic_1164(IEEE_P_2592010699);
    IEEE_P_1242562249 = xsi_get_engine_memory("ieee_p_1242562249");
    VL_P_2533777724 = xsi_get_engine_memory("vl_p_2533777724");
    IEEE_P_3620187407 = xsi_get_engine_memory("ieee_p_3620187407");
    IEEE_P_3499444699 = xsi_get_engine_memory("ieee_p_3499444699");
    IEEE_P_1367372525 = xsi_get_engine_memory("ieee_p_1367372525");
    UNISIM_P_3222816464 = xsi_get_engine_memory("unisim_p_3222816464");
    STD_TEXTIO = xsi_get_engine_memory("std_textio");
    IEEE_P_2717149903 = xsi_get_engine_memory("ieee_p_2717149903");
    IEEE_P_0774719531 = xsi_get_engine_memory("ieee_p_0774719531");

    return xsi_run_simulation(argc, argv);

}
