/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "E:/adlx/DLX_FFT_PROJECT/saleh_yosef/DLX_PROJECT/MAC.v";
static unsigned int ng1[] = {0U, 0U};
static unsigned int ng2[] = {1U, 0U};



static void Always_42_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;

LAB0:    t1 = (t0 + 4216U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(42, ng0);
    t2 = (t0 + 5032);
    *((int *)t2) = 1;
    t3 = (t0 + 4248);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(42, ng0);

LAB5:    xsi_set_current_line(43, ng0);
    t4 = (t0 + 1616U);
    t5 = *((char **)t4);
    t4 = (t5 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB6;

LAB7:    xsi_set_current_line(46, ng0);
    t2 = (t0 + 3296);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3136);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 2, 0LL);

LAB8:    goto LAB2;

LAB6:    xsi_set_current_line(44, ng0);
    t11 = (t0 + 472);
    t12 = *((char **)t11);
    t11 = (t0 + 3136);
    xsi_vlogvar_wait_assign_value(t11, t12, 0, 0, 2, 0LL);
    goto LAB8;

}

static void Always_50_1(char *t0)
{
    char t10[8];
    char t11[8];
    char t13[8];
    char t27[8];
    char t34[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    int t9;
    char *t12;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    char *t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    char *t25;
    char *t26;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    char *t33;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    char *t38;
    char *t39;
    char *t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    char *t48;
    char *t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    unsigned int t61;
    char *t62;
    unsigned int t63;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    unsigned int t67;
    char *t68;
    char *t69;
    unsigned int t70;
    unsigned int t71;
    unsigned int t72;
    char *t73;
    char *t74;
    unsigned int t75;
    unsigned int t76;
    unsigned int t77;
    unsigned int t78;
    char *t79;

LAB0:    t1 = (t0 + 4464U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(50, ng0);
    t2 = (t0 + 5048);
    *((int *)t2) = 1;
    t3 = (t0 + 4496);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(50, ng0);

LAB5:    xsi_set_current_line(51, ng0);
    t4 = (t0 + 3136);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);

LAB6:    t7 = (t0 + 472);
    t8 = *((char **)t7);
    t9 = xsi_vlog_unsigned_case_compare(t6, 2, t8, 32);
    if (t9 == 1)
        goto LAB7;

LAB8:    t2 = (t0 + 608);
    t3 = *((char **)t2);
    t9 = xsi_vlog_unsigned_case_compare(t6, 2, t3, 32);
    if (t9 == 1)
        goto LAB9;

LAB10:    t2 = (t0 + 744);
    t3 = *((char **)t2);
    t9 = xsi_vlog_unsigned_case_compare(t6, 2, t3, 32);
    if (t9 == 1)
        goto LAB11;

LAB12:
LAB14:
LAB13:    xsi_set_current_line(55, ng0);
    t2 = (t0 + 472);
    t3 = *((char **)t2);
    t2 = (t0 + 3296);
    xsi_vlogvar_assign_value(t2, t3, 0, 0, 2);

LAB15:    goto LAB2;

LAB7:    xsi_set_current_line(52, ng0);
    t7 = (t0 + 1936U);
    t12 = *((char **)t7);
    memset(t13, 0, 8);
    t7 = (t12 + 4);
    t14 = *((unsigned int *)t7);
    t15 = (~(t14));
    t16 = *((unsigned int *)t12);
    t17 = (t16 & t15);
    t18 = (t17 & 1U);
    if (t18 != 0)
        goto LAB16;

LAB17:    if (*((unsigned int *)t7) != 0)
        goto LAB18;

LAB19:    t20 = (t13 + 4);
    t21 = *((unsigned int *)t13);
    t22 = (!(t21));
    t23 = *((unsigned int *)t20);
    t24 = (t22 || t23);
    if (t24 > 0)
        goto LAB20;

LAB21:    memcpy(t34, t13, 8);

LAB22:    memset(t11, 0, 8);
    t62 = (t34 + 4);
    t63 = *((unsigned int *)t62);
    t64 = (~(t63));
    t65 = *((unsigned int *)t34);
    t66 = (t65 & t64);
    t67 = (t66 & 1U);
    if (t67 != 0)
        goto LAB30;

LAB31:    if (*((unsigned int *)t62) != 0)
        goto LAB32;

LAB33:    t69 = (t11 + 4);
    t70 = *((unsigned int *)t11);
    t71 = *((unsigned int *)t69);
    t72 = (t70 || t71);
    if (t72 > 0)
        goto LAB34;

LAB35:    t75 = *((unsigned int *)t11);
    t76 = (~(t75));
    t77 = *((unsigned int *)t69);
    t78 = (t76 || t77);
    if (t78 > 0)
        goto LAB36;

LAB37:    if (*((unsigned int *)t69) > 0)
        goto LAB38;

LAB39:    if (*((unsigned int *)t11) > 0)
        goto LAB40;

LAB41:    memcpy(t10, t79, 8);

LAB42:    t73 = (t0 + 3296);
    xsi_vlogvar_assign_value(t73, t10, 0, 0, 2);
    goto LAB15;

LAB9:    xsi_set_current_line(53, ng0);
    t2 = (t0 + 1776U);
    t4 = *((char **)t2);
    t2 = ((char*)((ng1)));
    memset(t13, 0, 8);
    t5 = (t4 + 4);
    t7 = (t2 + 4);
    t14 = *((unsigned int *)t4);
    t15 = *((unsigned int *)t2);
    t16 = (t14 ^ t15);
    t17 = *((unsigned int *)t5);
    t18 = *((unsigned int *)t7);
    t21 = (t17 ^ t18);
    t22 = (t16 | t21);
    t23 = *((unsigned int *)t5);
    t24 = *((unsigned int *)t7);
    t28 = (t23 | t24);
    t29 = (~(t28));
    t30 = (t22 & t29);
    if (t30 != 0)
        goto LAB46;

LAB43:    if (t28 != 0)
        goto LAB45;

LAB44:    *((unsigned int *)t13) = 1;

LAB46:    memset(t11, 0, 8);
    t12 = (t13 + 4);
    t31 = *((unsigned int *)t12);
    t32 = (~(t31));
    t35 = *((unsigned int *)t13);
    t36 = (t35 & t32);
    t37 = (t36 & 1U);
    if (t37 != 0)
        goto LAB47;

LAB48:    if (*((unsigned int *)t12) != 0)
        goto LAB49;

LAB50:    t20 = (t11 + 4);
    t41 = *((unsigned int *)t11);
    t42 = *((unsigned int *)t20);
    t43 = (t41 || t42);
    if (t43 > 0)
        goto LAB51;

LAB52:    t44 = *((unsigned int *)t11);
    t45 = (~(t44));
    t46 = *((unsigned int *)t20);
    t47 = (t45 || t46);
    if (t47 > 0)
        goto LAB53;

LAB54:    if (*((unsigned int *)t20) > 0)
        goto LAB55;

LAB56:    if (*((unsigned int *)t11) > 0)
        goto LAB57;

LAB58:    memcpy(t10, t33, 8);

LAB59:    t25 = (t0 + 3296);
    xsi_vlogvar_assign_value(t25, t10, 0, 0, 2);
    goto LAB15;

LAB11:    xsi_set_current_line(54, ng0);
    t2 = (t0 + 472);
    t4 = *((char **)t2);
    t2 = (t0 + 3296);
    xsi_vlogvar_assign_value(t2, t4, 0, 0, 2);
    goto LAB15;

LAB16:    *((unsigned int *)t13) = 1;
    goto LAB19;

LAB18:    t19 = (t13 + 4);
    *((unsigned int *)t13) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB19;

LAB20:    t25 = (t0 + 2096U);
    t26 = *((char **)t25);
    memset(t27, 0, 8);
    t25 = (t26 + 4);
    t28 = *((unsigned int *)t25);
    t29 = (~(t28));
    t30 = *((unsigned int *)t26);
    t31 = (t30 & t29);
    t32 = (t31 & 1U);
    if (t32 != 0)
        goto LAB23;

LAB24:    if (*((unsigned int *)t25) != 0)
        goto LAB25;

LAB26:    t35 = *((unsigned int *)t13);
    t36 = *((unsigned int *)t27);
    t37 = (t35 | t36);
    *((unsigned int *)t34) = t37;
    t38 = (t13 + 4);
    t39 = (t27 + 4);
    t40 = (t34 + 4);
    t41 = *((unsigned int *)t38);
    t42 = *((unsigned int *)t39);
    t43 = (t41 | t42);
    *((unsigned int *)t40) = t43;
    t44 = *((unsigned int *)t40);
    t45 = (t44 != 0);
    if (t45 == 1)
        goto LAB27;

LAB28:
LAB29:    goto LAB22;

LAB23:    *((unsigned int *)t27) = 1;
    goto LAB26;

LAB25:    t33 = (t27 + 4);
    *((unsigned int *)t27) = 1;
    *((unsigned int *)t33) = 1;
    goto LAB26;

LAB27:    t46 = *((unsigned int *)t34);
    t47 = *((unsigned int *)t40);
    *((unsigned int *)t34) = (t46 | t47);
    t48 = (t13 + 4);
    t49 = (t27 + 4);
    t50 = *((unsigned int *)t48);
    t51 = (~(t50));
    t52 = *((unsigned int *)t13);
    t53 = (t52 & t51);
    t54 = *((unsigned int *)t49);
    t55 = (~(t54));
    t56 = *((unsigned int *)t27);
    t57 = (t56 & t55);
    t58 = (~(t53));
    t59 = (~(t57));
    t60 = *((unsigned int *)t40);
    *((unsigned int *)t40) = (t60 & t58);
    t61 = *((unsigned int *)t40);
    *((unsigned int *)t40) = (t61 & t59);
    goto LAB29;

LAB30:    *((unsigned int *)t11) = 1;
    goto LAB33;

LAB32:    t68 = (t11 + 4);
    *((unsigned int *)t11) = 1;
    *((unsigned int *)t68) = 1;
    goto LAB33;

LAB34:    t73 = (t0 + 608);
    t74 = *((char **)t73);
    goto LAB35;

LAB36:    t73 = (t0 + 472);
    t79 = *((char **)t73);
    goto LAB37;

LAB38:    xsi_vlog_unsigned_bit_combine(t10, 32, t74, 32, t79, 32);
    goto LAB42;

LAB40:    memcpy(t10, t74, 8);
    goto LAB42;

LAB45:    t8 = (t13 + 4);
    *((unsigned int *)t13) = 1;
    *((unsigned int *)t8) = 1;
    goto LAB46;

LAB47:    *((unsigned int *)t11) = 1;
    goto LAB50;

LAB49:    t19 = (t11 + 4);
    *((unsigned int *)t11) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB50;

LAB51:    t25 = (t0 + 744);
    t26 = *((char **)t25);
    goto LAB52;

LAB53:    t25 = (t0 + 608);
    t33 = *((char **)t25);
    goto LAB54;

LAB55:    xsi_vlog_unsigned_bit_combine(t10, 32, t26, 32, t33, 32);
    goto LAB59;

LAB57:    memcpy(t10, t26, 8);
    goto LAB59;

}

static void Always_60_2(char *t0)
{
    char t9[8];
    char t25[8];
    char t27[8];
    char t54[8];
    char t68[8];
    char t75[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    int t7;
    char *t8;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    char *t24;
    unsigned int t26;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    char *t31;
    char *t32;
    char *t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    char *t41;
    char *t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    unsigned int t48;
    int t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    char *t55;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    char *t61;
    char *t62;
    unsigned int t63;
    unsigned int t64;
    unsigned int t65;
    char *t66;
    char *t67;
    unsigned int t69;
    unsigned int t70;
    unsigned int t71;
    unsigned int t72;
    unsigned int t73;
    char *t74;
    unsigned int t76;
    unsigned int t77;
    unsigned int t78;
    char *t79;
    char *t80;
    char *t81;
    unsigned int t82;
    unsigned int t83;
    unsigned int t84;
    unsigned int t85;
    unsigned int t86;
    unsigned int t87;
    unsigned int t88;
    char *t89;
    char *t90;
    unsigned int t91;
    unsigned int t92;
    unsigned int t93;
    unsigned int t94;
    unsigned int t95;
    unsigned int t96;
    unsigned int t97;
    unsigned int t98;
    int t99;
    int t100;
    unsigned int t101;
    unsigned int t102;
    unsigned int t103;
    unsigned int t104;
    unsigned int t105;
    unsigned int t106;
    char *t107;

LAB0:    t1 = (t0 + 4712U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(60, ng0);
    t2 = (t0 + 5064);
    *((int *)t2) = 1;
    t3 = (t0 + 4744);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(60, ng0);

LAB5:    xsi_set_current_line(62, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t0 + 2656);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(63, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 2976);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(64, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 2816);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(65, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 2496);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(67, ng0);
    t2 = (t0 + 3136);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);

LAB6:    t5 = (t0 + 472);
    t6 = *((char **)t5);
    t7 = xsi_vlog_unsigned_case_compare(t4, 2, t6, 32);
    if (t7 == 1)
        goto LAB7;

LAB8:    t2 = (t0 + 608);
    t3 = *((char **)t2);
    t7 = xsi_vlog_unsigned_case_compare(t4, 2, t3, 32);
    if (t7 == 1)
        goto LAB9;

LAB10:    t2 = (t0 + 744);
    t3 = *((char **)t2);
    t7 = xsi_vlog_unsigned_case_compare(t4, 2, t3, 32);
    if (t7 == 1)
        goto LAB11;

LAB12:
LAB13:    xsi_set_current_line(84, ng0);
    t2 = (t0 + 2096U);
    t3 = *((char **)t2);
    memset(t9, 0, 8);
    t2 = (t3 + 4);
    t10 = *((unsigned int *)t2);
    t11 = (~(t10));
    t12 = *((unsigned int *)t3);
    t13 = (t12 & t11);
    t14 = (t13 & 1U);
    if (t14 != 0)
        goto LAB23;

LAB24:    if (*((unsigned int *)t2) != 0)
        goto LAB25;

LAB26:    t6 = (t9 + 4);
    t16 = *((unsigned int *)t9);
    t17 = (!(t16));
    t18 = *((unsigned int *)t6);
    t19 = (t17 || t18);
    if (t19 > 0)
        goto LAB27;

LAB28:    memcpy(t27, t9, 8);

LAB29:    memset(t54, 0, 8);
    t55 = (t27 + 4);
    t56 = *((unsigned int *)t55);
    t57 = (~(t56));
    t58 = *((unsigned int *)t27);
    t59 = (t58 & t57);
    t60 = (t59 & 1U);
    if (t60 != 0)
        goto LAB37;

LAB38:    if (*((unsigned int *)t55) != 0)
        goto LAB39;

LAB40:    t62 = (t54 + 4);
    t63 = *((unsigned int *)t54);
    t64 = *((unsigned int *)t62);
    t65 = (t63 || t64);
    if (t65 > 0)
        goto LAB41;

LAB42:    memcpy(t75, t54, 8);

LAB43:    t107 = (t0 + 2656);
    xsi_vlogvar_assign_value(t107, t75, 0, 0, 1);
    goto LAB2;

LAB7:    xsi_set_current_line(68, ng0);

LAB14:    xsi_set_current_line(69, ng0);
    t5 = ((char*)((ng2)));
    t8 = (t0 + 2976);
    xsi_vlogvar_assign_value(t8, t5, 0, 0, 1);
    xsi_set_current_line(70, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 2816);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(71, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 2496);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB13;

LAB9:    xsi_set_current_line(73, ng0);

LAB15:    xsi_set_current_line(74, ng0);
    t2 = (t0 + 1936U);
    t5 = *((char **)t2);
    memset(t9, 0, 8);
    t2 = (t5 + 4);
    t10 = *((unsigned int *)t2);
    t11 = (~(t10));
    t12 = *((unsigned int *)t5);
    t13 = (t12 & t11);
    t14 = (t13 & 1U);
    if (t14 != 0)
        goto LAB19;

LAB17:    if (*((unsigned int *)t2) == 0)
        goto LAB16;

LAB18:    t6 = (t9 + 4);
    *((unsigned int *)t9) = 1;
    *((unsigned int *)t6) = 1;

LAB19:    t8 = (t9 + 4);
    t15 = (t5 + 4);
    t16 = *((unsigned int *)t5);
    t17 = (~(t16));
    *((unsigned int *)t9) = t17;
    *((unsigned int *)t8) = 0;
    if (*((unsigned int *)t15) != 0)
        goto LAB21;

LAB20:    t22 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t22 & 1U);
    t23 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t23 & 1U);
    t24 = (t0 + 2976);
    xsi_vlogvar_assign_value(t24, t9, 0, 0, 1);
    xsi_set_current_line(75, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2816);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(76, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2496);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB13;

LAB11:    xsi_set_current_line(78, ng0);

LAB22:    xsi_set_current_line(79, ng0);
    t2 = ((char*)((ng2)));
    t5 = (t0 + 2976);
    xsi_vlogvar_assign_value(t5, t2, 0, 0, 1);
    xsi_set_current_line(80, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 2816);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(81, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 2496);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB13;

LAB16:    *((unsigned int *)t9) = 1;
    goto LAB19;

LAB21:    t18 = *((unsigned int *)t9);
    t19 = *((unsigned int *)t15);
    *((unsigned int *)t9) = (t18 | t19);
    t20 = *((unsigned int *)t8);
    t21 = *((unsigned int *)t15);
    *((unsigned int *)t8) = (t20 | t21);
    goto LAB20;

LAB23:    *((unsigned int *)t9) = 1;
    goto LAB26;

LAB25:    t5 = (t9 + 4);
    *((unsigned int *)t9) = 1;
    *((unsigned int *)t5) = 1;
    goto LAB26;

LAB27:    t8 = (t0 + 1936U);
    t15 = *((char **)t8);
    memset(t25, 0, 8);
    t8 = (t15 + 4);
    t20 = *((unsigned int *)t8);
    t21 = (~(t20));
    t22 = *((unsigned int *)t15);
    t23 = (t22 & t21);
    t26 = (t23 & 1U);
    if (t26 != 0)
        goto LAB30;

LAB31:    if (*((unsigned int *)t8) != 0)
        goto LAB32;

LAB33:    t28 = *((unsigned int *)t9);
    t29 = *((unsigned int *)t25);
    t30 = (t28 | t29);
    *((unsigned int *)t27) = t30;
    t31 = (t9 + 4);
    t32 = (t25 + 4);
    t33 = (t27 + 4);
    t34 = *((unsigned int *)t31);
    t35 = *((unsigned int *)t32);
    t36 = (t34 | t35);
    *((unsigned int *)t33) = t36;
    t37 = *((unsigned int *)t33);
    t38 = (t37 != 0);
    if (t38 == 1)
        goto LAB34;

LAB35:
LAB36:    goto LAB29;

LAB30:    *((unsigned int *)t25) = 1;
    goto LAB33;

LAB32:    t24 = (t25 + 4);
    *((unsigned int *)t25) = 1;
    *((unsigned int *)t24) = 1;
    goto LAB33;

LAB34:    t39 = *((unsigned int *)t27);
    t40 = *((unsigned int *)t33);
    *((unsigned int *)t27) = (t39 | t40);
    t41 = (t9 + 4);
    t42 = (t25 + 4);
    t43 = *((unsigned int *)t41);
    t44 = (~(t43));
    t45 = *((unsigned int *)t9);
    t7 = (t45 & t44);
    t46 = *((unsigned int *)t42);
    t47 = (~(t46));
    t48 = *((unsigned int *)t25);
    t49 = (t48 & t47);
    t50 = (~(t7));
    t51 = (~(t49));
    t52 = *((unsigned int *)t33);
    *((unsigned int *)t33) = (t52 & t50);
    t53 = *((unsigned int *)t33);
    *((unsigned int *)t33) = (t53 & t51);
    goto LAB36;

LAB37:    *((unsigned int *)t54) = 1;
    goto LAB40;

LAB39:    t61 = (t54 + 4);
    *((unsigned int *)t54) = 1;
    *((unsigned int *)t61) = 1;
    goto LAB40;

LAB41:    t66 = (t0 + 1776U);
    t67 = *((char **)t66);
    memset(t68, 0, 8);
    t66 = (t67 + 4);
    t69 = *((unsigned int *)t66);
    t70 = (~(t69));
    t71 = *((unsigned int *)t67);
    t72 = (t71 & t70);
    t73 = (t72 & 1U);
    if (t73 != 0)
        goto LAB44;

LAB45:    if (*((unsigned int *)t66) != 0)
        goto LAB46;

LAB47:    t76 = *((unsigned int *)t54);
    t77 = *((unsigned int *)t68);
    t78 = (t76 & t77);
    *((unsigned int *)t75) = t78;
    t79 = (t54 + 4);
    t80 = (t68 + 4);
    t81 = (t75 + 4);
    t82 = *((unsigned int *)t79);
    t83 = *((unsigned int *)t80);
    t84 = (t82 | t83);
    *((unsigned int *)t81) = t84;
    t85 = *((unsigned int *)t81);
    t86 = (t85 != 0);
    if (t86 == 1)
        goto LAB48;

LAB49:
LAB50:    goto LAB43;

LAB44:    *((unsigned int *)t68) = 1;
    goto LAB47;

LAB46:    t74 = (t68 + 4);
    *((unsigned int *)t68) = 1;
    *((unsigned int *)t74) = 1;
    goto LAB47;

LAB48:    t87 = *((unsigned int *)t75);
    t88 = *((unsigned int *)t81);
    *((unsigned int *)t75) = (t87 | t88);
    t89 = (t54 + 4);
    t90 = (t68 + 4);
    t91 = *((unsigned int *)t54);
    t92 = (~(t91));
    t93 = *((unsigned int *)t89);
    t94 = (~(t93));
    t95 = *((unsigned int *)t68);
    t96 = (~(t95));
    t97 = *((unsigned int *)t90);
    t98 = (~(t97));
    t99 = (t92 & t94);
    t100 = (t96 & t98);
    t101 = (~(t99));
    t102 = (~(t100));
    t103 = *((unsigned int *)t81);
    *((unsigned int *)t81) = (t103 & t101);
    t104 = *((unsigned int *)t81);
    *((unsigned int *)t81) = (t104 & t102);
    t105 = *((unsigned int *)t75);
    *((unsigned int *)t75) = (t105 & t101);
    t106 = *((unsigned int *)t75);
    *((unsigned int *)t75) = (t106 & t102);
    goto LAB50;

}


extern void work_m_00000000003630370168_0948342941_init()
{
	static char *pe[] = {(void *)Always_42_0,(void *)Always_50_1,(void *)Always_60_2};
	xsi_register_didat("work_m_00000000003630370168_0948342941", "isim/IO_LS_IO_LS_sch_tb_isim_beh.exe.sim/work/m_00000000003630370168_0948342941.didat");
	xsi_register_executes(pe);
}
